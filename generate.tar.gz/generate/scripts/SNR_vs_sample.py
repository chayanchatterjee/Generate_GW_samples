import matplotlib.pyplot as plt

samples = []
snr=[11.83,15.31,10.25,10.31,16.96,13.59,14.28,11.62,12.65,12.24,15.91,13.41,15.03,12.80,15.09,15.19,14.27,17.96,17.22,18.97,12.38,16.33,17.61,16.23,17.72,13.25,15.47,12.00,10.98,11.56,10.46,16.16] 
for i in range(32):
     samples.append(i)

plt.scatter(samples, snr)
plt.xlabel('Sample ID')
plt.ylabel('Injection SNR')
plt.savefig('SNR_vs_sample.png')
