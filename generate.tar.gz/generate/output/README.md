# Output Data

This folder will hold all generated data (i.e., the script outputs), and this README file is necessary to ensure git keeps the folder in the repository :)
